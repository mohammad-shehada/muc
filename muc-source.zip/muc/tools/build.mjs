import fs from 'node:fs';import path from 'node:path';import{fileURLToPath}from'node:url';import{stripTypeScriptTypes}from'node:module';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const js=stripTypeScriptTypes(fs.readFileSync(path.join(root,'src/app.ts'),'utf8'),{mode:'transform'});fs.writeFileSync(path.join(root,'dist/app.js'),js);
console.log('Built TypeScript application.');
import crypto from 'node:crypto';
const hash=crypto.createHash('sha256').update(js).update(fs.readFileSync(path.join(root,'dist/app.css'))).digest('hex').slice(0,12);
fs.writeFileSync(path.join(root,'dist/sw.js'),fs.readFileSync(path.join(root,'tools/sw-template.js'),'utf8').replace('BUILD_HASH',hash));
