from pathlib import Path
import re,shutil,zipfile,hashlib,json,subprocess
R=Path(__file__).resolve().parents[1];out=R/'tmp/github-release';out.mkdir(parents=True,exist_ok=True)
for p in (R/'dist').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(R/'dist');paper=rel.parts[0]=='papers'
 name=('paper-'+p.name) if paper and len(rel.parts)==2 else p.name
 target=out/name
 if p.suffix in ['.html','.css','.js','.svg','.webmanifest']:
  s=p.read_text()
  if paper:
   s=s.replace('url(assets/','url(').replace('href="sources/','href="').replace("'sources/","'").replace('"sources/','"')
   if p.suffix=='.html':s=re.sub(r'((?:src|href)=["\'])([\w-]+\.(?:js|css))',r'\1paper-\2',s)
  else:s=s.replace('papers/sources/','').replace('papers/assets/','').replace('papers/','paper-')
  target.write_text(s)
 else:shutil.copy2(p,target)
shutil.copy2(R/'src/app.ts',out/'app.ts');shutil.copy2(R/'tools/build_content.py',out/'build_content.py')
with zipfile.ZipFile(out/'muc-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src','tools','dist']:
  for p in (R/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:z.write(p,'muc/'+str(p.relative_to(R)))
 for name in ['README.md','.gitignore']:z.write(R/name,'muc/'+name)
readme=R.joinpath('README.md').read_text();readme=readme.replace('# muc','# muc\n\nهذا المستودع يحتوي توزيع الموقع الجاهز لـGitHub Pages. [تنزيل المصدر الكامل بمجلداته](muc-source.zip).\n\nملفا app.ts وbuild_content.py للقراءة المباشرة؛ لإعادة البناء فك muc-source.zip ثم نفّذ الخطوات أدناه داخل مجلد muc.\n',1);(out/'README.md').write_text(readme)
# Validate all static entrypoint files after flattening.
for name in ['index.html','paper-index.html']:
 for ref in re.findall(r'(?:src|href)="([^"#]+)"',(out/name).read_text()):
  if ref.startswith(('http','blob:','data:','#')):continue
  assert (out/ref.split('?')[0]).exists(),(name,ref)
old=R.parent/'44_Networks_Weekly_Exams';lock={str(p.relative_to(old/'dist')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (old/'dist').rglob('*') if p.is_file()}
(R/'source-lock.json').write_text(json.dumps(dict(repository='mohammad-shehada/networks-weekly-exams-ar',commit=subprocess.check_output(['git','-C',str(old),'rev-parse','HEAD'],text=True).strip(),files=lock),indent=2))
assert not subprocess.check_output(['git','-C',str(old),'status','--porcelain'],text=True).strip(),'Original repository has pending changes'
print('Release ready:',len(list(out.iterdir())),'files. Original repository clean and unchanged.')
