from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parents[1]/'dist'
for size in [192,512]:
 im=Image.new('RGB',(size,size));p=im.load()
 for y in range(size):
  for x in range(size):
   t=(x+y)/(2*size);p[x,y]=(int(102*(1-t)+54*t),int(181*(1-t)+120*t),int(250*(1-t)+227*t))
 d=ImageDraw.Draw(im);s=size/192;d.rounded_rectangle([42*s,52*s,150*s,138*s],radius=18*s,fill='white');d.polygon([(63*s,125*s),(95*s,132*s),(63*s,158*s)],fill='white')
 font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Bold.ttf',int(44*s));b=d.textbbox((0,0),'muc',font=font);d.text(((size-(b[2]-b[0]))/2,72*s),'muc',font=font,fill='#3983e8')
 im.save(r/f'icon-{size}.png')
